/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_tarea1;

/**
 *
 * @author USUARIO
 */

import java.util.Scanner;

public class Principal_Tarea1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner datos = new Scanner(System.in);
        
        Trabajador primero = new Trabajador();
        String nombreTrabajador;
        String apellidoTrabajador;
        int codigoTrabajador;
        double salarioTrabajador;
        
        System.out.println("INGRESE SU NOMBRE: ");
         nombreTrabajador = datos.nextLine();
         primero.setNombre(nombreTrabajador);
        
        System.out.println("INGRESE SU APELLIDO: ");
        apellidoTrabajador = datos.nextLine();
        primero.setApellidos(apellidoTrabajador);
        
        System.out.println("INGRESE EL CODIGO: ");
        codigoTrabajador = datos.nextInt();
        primero.setCodigo(codigoTrabajador);
        
        System.out.println("INGRESE EL SALARIO MENSUAL:");
        salarioTrabajador = datos.nextDouble();
        primero.setSalario(salarioTrabajador);
        
        System.out.println("DATOS GENERALES DEL TRABAJADOR: ");
            System.out.println("NOMBRE: " + primero.getNombre());
            System.out.println("APELLIDO: " + primero.getApellidos());
            System.out.println("CODIGO: " + primero.getCodigo());
            System.out.println("SALARIO MENSUAL: " + primero.getSalario());
        System.out.println("SALARIO DIARIO: " + primero.getSalario() / 30);
    }
    
}
